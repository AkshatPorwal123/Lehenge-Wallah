let secondbuttoncreated=false;
let flag=false;

function handleForm(event)
{
    event.preventDefault();
    const name=document.getElementById('name').value;
    const address=document.getElementById('address').value;
    const phone=document.getElementById('phone').value;
    if(!name||!address||!phone)
    {
        alert('Please fill in all the details before submitting');
    }
    const messageDiv = document.getElementById('formMessage');
    messageDiv.innerText = "Form submitted successfully!";
}
function payment()
{
    if(!secondbuttoncreated)
    {
        document.getElementById('message').innerText+="Security money successfully deposited! Order has been dispatched and received.\n";
        const box=document.createElement('button');
        box.innerText='Pay the rental amount';
        box.onclick=payment1;
        document.getElementById('msg').appendChild(box);
        secondbuttoncreated=true;
    }
}
function payment1()
{
    if(!flag)
    {
        const msgcont=document.getElementById('msg');
        const msg=document.createElement('div');
        msg.innerText="Rental amount successfully paid. Order has been received";
        msgcont.appendChild(msg);
        flag=true;
    } 
}
