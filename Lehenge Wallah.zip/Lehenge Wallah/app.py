from flask import Flask,request,redirect,render_template,url_for,flash
import mysql.connector
import os
from werkzeug.utils import secure_filename

app=Flask(__name__)
app.secret_key="secret"

UPLOAD_FOLDER='static/uploads'
app.config['UPLOAD_FOLDER']=UPLOAD_FOLDER

db=mysql.connector.connect(
    host="localhost",
    database="disha",
    user="root",
    password="standard20"
)

@app.route('/')
def home():
    return render_template('homepage.html')

@app.route('/women')
def women():
    cursor=db.cursor(dictionary=True)
    cursor.execute("select*from clothes where category='women' order by id desc")
    clothes=cursor.fetchall()
    return render_template('women.html',clothes=clothes)    

@app.route('/men')
def men():
    cursor=db.cursor(dictionary=True)
    cursor.execute("select*from clothes where category='men' order by id desc")
    clothes=cursor.fetchall()
    return render_template('men.html',clothes=clothes)  

@app.route('/kids')
def kids():
    cursor=db.cursor(dictionary=True)
    cursor.execute("select*from clothes where category='kids' order by id desc")
    clothes=cursor.fetchall()
    return render_template('kids.html',clothes=clothes)  

@app.route('/buy')
def buy():
    return render_template('buy.html')

@app.route('/sell',methods=['GET','POST'])
def sell():
    if request.method=='POST':
        category=request.form['category']
        clothtype=request.form['clothtype']
        brand=request.form['brand']
        price=request.form['price']
        height=request.form['height']
        waist=request.form['waist']
        hips=request.form['hips']
        size=request.form['size']
        description=request.form['description']
        file=request.files.get('photo')
        filename=secure_filename(file.filename)
        filepath=os.path.join(app.config['UPLOAD_FOLDER'],filename)
        file.save(filepath)
        file_url=f"/{filepath.replace('\\','/')}"
        cursor=db.cursor()
        sql="""insert into clothes (category, name, brand, price, height, waist, hips, size, description, url)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s) """
        values = (category, clothtype, brand, price, height, waist, hips, size, description, file_url)
        cursor.execute(sql,values)
        db.commit()
        cursor.close()
        return redirect(url_for('sell'))
    return render_template('sell.html')

@app.route('/buynow')
def buynow():
    return render_template('buynow.html')

if __name__=="__main__":
    app.run(debug=True)