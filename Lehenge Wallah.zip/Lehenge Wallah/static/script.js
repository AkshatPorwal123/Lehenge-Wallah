let index = 0;
const tracks = document.querySelectorAll(".bg-track");
setInterval(() =>{
        index = (index + 1) % 3;

        tracks.forEach(track => {
            track.style.transform = `translateY(-${index * 100}vh)`;
        });
    }, 2000);
function show()
{
    document.getElementById('message').innerText="You cloth has been submitted successfully!";
}
function show2()
{
    document.getElementById('message').innerText="Security Money paid successfully! The order has been dispatched and received";
    document.getElementById('pay50').disabled=true;
    document.getElementById('payfull').style.display="inline-block";
}
function show3()
{
    document.getElementById('message').innerText="Total amount paid successfully";
    document.getElementById('payfull').disabled=true;
}